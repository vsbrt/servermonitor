package com.googlecode.dex2jar.tools.to;

public class Do {

    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.println("This is not support!");
    }

}
