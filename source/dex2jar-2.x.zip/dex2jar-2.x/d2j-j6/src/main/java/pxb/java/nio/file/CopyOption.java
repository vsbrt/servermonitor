package pxb.java.nio.file;

public interface CopyOption {
}
