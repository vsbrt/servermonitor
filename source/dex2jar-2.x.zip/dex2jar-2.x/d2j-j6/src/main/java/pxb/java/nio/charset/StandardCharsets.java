package pxb.java.nio.charset;

import java.nio.charset.Charset;

public class StandardCharsets {
    public static Charset UTF_8 = Charset.forName("UTF-8");
    public static Charset ISO_8859_1 = Charset.forName("iso-8859-1");
}
